﻿using System.Windows.Controls;

namespace FlightSimulator.View.Controls
{
    /// <summary>
    /// Interaction logic for DataTable.xaml.
    /// </summary>
    public partial class DataTable : UserControl
    {
        public DataTable()
        {
            //This function initialize all the component from the xml.
            InitializeComponent();
        }
    }
}
