﻿using System.Windows.Controls;

namespace FlightSimulator.View.Controls
{
    /// <summary>
    /// Interaction logic for Map.xaml.
    /// </summary>
    public partial class Map : UserControl
    {
        public Map()
        {
            //This function initialize all the component from the xml.
            InitializeComponent();
        }
    }
}
